package org.example;

public enum Shapes {
    RECTANGLE,
    SQUARE,
    ELLIPSE,
    CIRCLE
}
